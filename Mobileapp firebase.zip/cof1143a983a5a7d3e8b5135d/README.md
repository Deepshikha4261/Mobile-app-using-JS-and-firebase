# cof1143a983a5a7d3e8b5135d

Quick start:

```
$ npm install
$ npm start
````

a mobie app using firebase

Happy Coding!
